/*
 * HM01B0_CAPTURE.h
 *
 *  Created on: Nov 25, 2018
 *      Author: Ali
 */

#ifndef HM01B0_CAPTURE_H_
#define HM01B0_CAPTURE_H_
//
///*test add*/
//#include <nrfx.h>
//#include <nrfx_spis.h>
//
////#if NRFX_CHECK(NRFX_SPIS_ENABLED)
////
////#if !(NRFX_CHECK(NRFX_SPIS0_ENABLED) || NRFX_CHECK(NRFX_SPIS1_ENABLED) || \
////      NRFX_CHECK(NRFX_SPIS2_ENABLED))
////#error "No enabled SPIS instances. Check <nrfx_config.h>."
////#endif
//
//
////#include "prs/nrfx_prs.h"
//
//#define NRFX_LOG_MODULE SPIS
//#include <nrfx_log.h>
///*test add finish*/



#include "HM01B0_GPIO.h"
#include "HM01B0_FUNC.h"
#include "HM01B0_CLK.h"

//#include "HM01B0_GPIO.h"
#include "HM01B0_SPI.h"

/*if capture_mode=0x01 => it streams. This is useful for tetsing purposes*/
/*if capture_mode=0x03 => it takes frame_count shots. */
#define capture_mode  0x01
#define CAMERA_DEBUG 1
#define BLE_DEBUG 0




//static uint32_t ble_bytes_sent_counter = 0;
uint32_t ble_bytes_sent_counter = 0;

void hm_peripheral_init(void);


void hm_single_capture(void);


void hm_single_capture_spi(void);

void hm_single_capture_spi_832(void);


#endif /* HM01B0_CAPTURE_H_ */